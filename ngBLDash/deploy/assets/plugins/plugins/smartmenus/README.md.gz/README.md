# SmartMenus

jQuery website menu plugin. Responsive and accessible list-based website menus that work on all devices.
Check out [the demo page](http://vadikom.github.io/smartmenus/src/demo/).

## Homepage

http://www.smartmenus.org/

## Download

Download the ZIP package which includes a basic demo:

http://www.smartmenus.org/download/

## Getting started and API documentation

http://www.smartmenus.org/docs/

## Bugs and issues

https://github.com/vadikom/smartmenus/issues

## Support forums

http://www.smartmenus.org/support/forums/